
package shrabanti;


public class Bus {
       String departureCity;
    String destinationCity;
    String date;
    int availableSeats;

    public Bus(String departureCity, String destinationCity, String date, int availableSeats) {
        this.departureCity = departureCity;
        this.destinationCity = destinationCity;
        this.date = date;
        this.availableSeats = availableSeats;
    }
    
}
